
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, CheckCircle, Phone, Mail, MapPin, Globe } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const HomePage = () => {
  const fadeInUp = {
    initial: { opacity: 0, y: 60 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const products = [
    {
      image: 'https://horizons-cdn.hostinger.com/38727cf0-565e-4ae8-b59b-37f2b9952d98/7885caf093d35e71a809bbaf759d8500.jpg',
      title: 'Premium Quality',
      description: 'Manufactured with precision engineering and highest quality materials for optimal performance'
    },
    {
      image: 'https://images.unsplash.com/photo-1683974106680-bdebbe73d250',
      title: 'Superior Performance',
      description: 'Designed to deliver maximum efficiency, fuel economy, and engine longevity'
    }
  ];

  const qualityFeatures = [
    'Rigorous 6-stage quality testing',
    'ISO certified manufacturing',
    'Heat resistance up to 1000°C',
    'Extended durability guarantee'
  ];

  return (
    <>
      <Helmet>
        <title>JIANSH Spark Plugs - Premium Spark Plugs for Superior Performance</title>
        <meta name="description" content="JIANSH Spark Plugs manufactures premium quality spark plugs with superior performance, durability, and reliability. Trusted by professionals worldwide." />
      </Helmet>

      <Header />

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://horizons-cdn.hostinger.com/38727cf0-565e-4ae8-b59b-37f2b9952d98/4d6e21b485d448b1e5995e888266a397.png"
            alt="JIANSH Premium Spark Plug"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 gradient-overlay" />
          <div className="absolute inset-0 pattern-dots opacity-30" />
        </div>

        {/* Hero Content */}
        <motion.div
          initial="initial"
          animate="animate"
          variants={staggerContainer}
          className="relative z-10 text-center px-6 max-w-5xl mx-auto"
        >
          <motion.h1
            variants={fadeInUp}
            className="text-white mb-6 drop-shadow-2xl"
          >
            JIANSH SPARK PLUGS
          </motion.h1>
          
          <motion.p
            variants={fadeInUp}
            className="text-2xl md:text-4xl text-white font-bold mb-4 tracking-wide"
          >
            Premium Spark Plugs for Superior Performance
          </motion.p>
          
          <motion.p
            variants={fadeInUp}
            className="text-lg md:text-xl text-gray-200 mb-12 max-w-3xl mx-auto leading-relaxed"
          >
            Engineered with precision, tested for excellence. Experience unmatched reliability and performance with JIANSH.
          </motion.p>
          
          <motion.div variants={fadeInUp}>
            <Link to="/contact" className="btn-primary inline-flex items-center space-x-2">
              <span>Send Inquiry</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2 z-10"
        >
          <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-1.5 h-1.5 bg-[#FF3333] rounded-full mt-2"
            />
          </div>
        </motion.div>
      </section>

      {/* Company Introduction */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h2 className="text-black mb-6">
              Leading Manufacturer of <span className="text-gradient">Premium Spark Plugs</span>
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed mb-8">
              JIANSH Spark Plugs is a trusted name in automotive excellence, specializing in the manufacturing of high-performance spark plugs. With years of industry experience and cutting-edge technology, we deliver products that meet the highest standards of quality, durability, and performance.
            </p>
            <Link to="/about" className="btn-outline inline-flex items-center space-x-2">
              <span>Learn More About Us</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Product Showcase */}
      <section className="section-padding bg-gray-50 pattern-grid">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-black mb-4">
              Our <span className="text-gradient">Products</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Precision-engineered spark plugs designed for maximum performance and longevity
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {products.map((product, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="card-industrial group cursor-pointer"
              >
                <div className="overflow-hidden mb-6">
                  <img
                    src={product.image}
                    alt={product.title}
                    className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <h3 className="text-black mb-3 group-hover:text-[#FF3333] transition-colors duration-300">
                  {product.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {product.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Quality Assurance Highlight */}
      <section className="section-padding bg-black text-white relative overflow-hidden">
        <div className="absolute inset-0 pattern-dots opacity-10" />
        
        <div className="container-custom relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-white mb-6">
                Uncompromising <span className="text-[#FF3333]">Quality Standards</span>
              </h2>
              <p className="text-gray-300 text-lg leading-relaxed mb-8">
                Every JIANSH spark plug undergoes rigorous testing through our comprehensive 6-stage quality assurance process. We ensure that each product meets international standards and exceeds customer expectations.
              </p>
              
              <div className="space-y-4 mb-8">
                {qualityFeatures.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="flex items-center space-x-3"
                  >
                    <CheckCircle className="w-6 h-6 text-[#FF3333] flex-shrink-0" />
                    <span className="text-white font-medium">{feature}</span>
                  </motion.div>
                ))}
              </div>

              <Link to="/quality-checks" className="btn-primary inline-flex items-center space-x-2">
                <span>View Quality Process</span>
                <ArrowRight className="w-5 h-5" />
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <div className="industrial-shadow-lg">
                <img
                  src="https://horizons-cdn.hostinger.com/38727cf0-565e-4ae8-b59b-37f2b9952d98/4d6e21b485d448b1e5995e888266a397.png"
                  alt="JIANSH Quality Testing Process"
                  className="w-full h-auto"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Preview */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-black mb-4">
              Get in <span className="text-gradient">Touch</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Have questions or need assistance? Our team is here to help you find the perfect spark plug solution.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0 }}
              className="card-industrial text-center group"
            >
              <Phone className="w-12 h-12 text-[#FF3333] mx-auto mb-4 group-hover:scale-110 transition-transform duration-300" />
              <h4 className="text-black mb-2">Phone</h4>
              <a href="tel:8595010027" className="text-gray-600 hover:text-[#FF3333] transition-colors duration-300">
                8595010027
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="card-industrial text-center group"
            >
              <Mail className="w-12 h-12 text-[#FF3333] mx-auto mb-4 group-hover:scale-110 transition-transform duration-300" />
              <h4 className="text-black mb-2">Email</h4>
              <a href="mailto:jianshsparkplug@gmail.com" className="text-gray-600 hover:text-[#FF3333] transition-colors duration-300 break-all text-sm">
                jianshsparkplug@gmail.com
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="card-industrial text-center group"
            >
              <Globe className="w-12 h-12 text-[#FF3333] mx-auto mb-4 group-hover:scale-110 transition-transform duration-300" />
              <h4 className="text-black mb-2">Website</h4>
              <p className="text-gray-600">www.jianshsparkplugs.com</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="card-industrial text-center group"
            >
              <MapPin className="w-12 h-12 text-[#FF3333] mx-auto mb-4 group-hover:scale-110 transition-transform duration-300" />
              <h4 className="text-black mb-2">Location</h4>
              <p className="text-gray-600">
                S-24, Balram Nagar<br />
                Loni Industrial Area<br />
                Loni Estate, Ghaziabad<br />
                Uttar Pradesh 201102<br />
                India
              </p>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-center mt-12"
          >
            <Link to="/contact" className="btn-secondary inline-flex items-center space-x-2">
              <span>Contact Us Now</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default HomePage;
